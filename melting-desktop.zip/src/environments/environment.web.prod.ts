export const APP_CONFIG = {
  production: true,
  environment: 'WEB-PROD'
};
